import 'package:bloodbank/Color/Colors.dart';
import 'package:bloodbank/Database/dbHelper.dart';
import 'package:bloodbank/LoginScreen/login1.dart';
import 'package:bloodbank/Wait.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MainHomePage extends StatefulWidget {
  const MainHomePage({super.key});

  @override
  State<MainHomePage> createState() => _MainHomePageState();
}

class _MainHomePageState extends State<MainHomePage> {
  DatabaseHelper myDBhelper = DatabaseHelper.instance;
  List<Map<String, dynamic>> allBlooddone = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _query();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List of blood'),
        backgroundColor: MyColors.primaryColor,
        foregroundColor: MyColors.white,
        actions: [
          IconButton(
              onPressed: () async {
                var sharedpref = await SharedPreferences.getInstance();
                sharedpref.setBool(SplashScreenState.KEYLOGIN2, false);
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => Login_option()));
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: Column(children: [
        Expanded(
            child: ListView.builder(
                itemCount: allBlooddone.length,
                itemBuilder: (context, index) {
                  var item = allBlooddone[index];

                  return Container(
                    child: Column(
                      children: [
                        ListTile(
                          title: Text("${item['fnameU']}  ${item['lnameU']}"),
                          leading: CircleAvatar(
                            child: Text('${item['blood_group']}'),
                            minRadius: 20,
                            maxRadius: 30,
                          ),
                          trailing: IconButton(
                              onPressed: () {
                                //  _delete(item['_id']);
                              },
                              icon: Icon(Icons.delete)),
                          subtitle: Text(
                              "${item['bank']} \nNumber:${item['Mobile']} \nMobile :${item['cityU']} "),
                        ),
                        Divider(
                          color: Colors.black,
                          thickness: 1,
                        )
                      ],
                    ),
                  );
                }))
      ]),
    );
  }

  void _query() async {
    final allRows = await myDBhelper.queryAllbloodlist();
    print('query all rows:');
    allRows.forEach(print);
    allBlooddone = allRows;
    setState(() {});
  }
}
