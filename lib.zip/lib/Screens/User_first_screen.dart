import 'package:flutter/material.dart';

class UserFirstScreen extends StatefulWidget {
  const UserFirstScreen({super.key});

  @override
  State<UserFirstScreen> createState() => _UserFirstScreenState();
}

class _UserFirstScreenState extends State<UserFirstScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Text('h0ell0'),
        ],
      ),
    );
  }
}
