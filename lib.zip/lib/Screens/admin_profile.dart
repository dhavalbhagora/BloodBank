import 'package:bloodbank/Color/Colors.dart';
import 'package:bloodbank/Database/dbHelper.dart';
import 'package:flutter/material.dart';

class DonnerReq extends StatefulWidget {
  const DonnerReq({super.key});

  @override
  State<DonnerReq> createState() => _DonnerReqState();
}

class _DonnerReqState extends State<DonnerReq> {
  DatabaseHelper myDBhelper = DatabaseHelper.instance;
  List<Map<String, dynamic>> allBlooddone = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _query();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Donner List'),
        backgroundColor: MyColors.primaryColor,
        foregroundColor: MyColors.white,
      ),
      backgroundColor: MyColors.white,
      body: ListView.builder(
          itemCount: allBlooddone.length,
          itemBuilder: (context, index) {
            var item = allBlooddone[index];

            return Container(
              child: Column(
                children: [
                  ListTile(
                    title: Text(
                      "Donner Name: ${item['nameR']}",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    trailing: Column(
                      children: [
                        IconButton(
                            onPressed: () {
                              //  _delete(item['_id']);
                            },
                            icon: Icon(Icons.done)),
                      ],
                    ),
                    subtitle: Text(
                      '\nContact : ${item['phoneR']}\nBankName : ${item['Bank']} \nCity: ${item['CityR']}',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                  Divider(
                    color: Colors.black,
                    thickness: 1,
                  )
                ],
              ),
            );
          }),
    );
  }

  void _query() async {
    final allRows = await myDBhelper.queryAllDonnerreq();
    print('query all rows:');
    allRows.forEach(print);
    allBlooddone = allRows;
    setState(() {});
  }
}
