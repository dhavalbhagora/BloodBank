import 'package:bloodbank/Color/Colors.dart';
import 'package:bloodbank/Database/dbHelper.dart';
import 'package:flutter/material.dart';

class DonnerList extends StatefulWidget {
  const DonnerList({super.key});

  @override
  State<DonnerList> createState() => _DonnerListState();
}

class _DonnerListState extends State<DonnerList> {
  DatabaseHelper myDBhelper = DatabaseHelper.instance;
  List<Map<String, dynamic>> allBlooddone = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _query();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Donner List'),
        backgroundColor: MyColors.primaryColor,
        foregroundColor: MyColors.white,
      ),
      backgroundColor: MyColors.white,
      body: ListView.builder(
          itemCount: allBlooddone.length,
          itemBuilder: (context, index) {
            var item = allBlooddone[index];

            return Container(
              child: Column(
                children: [
                  ListTile(
                    title: Text(
                      "Donner Name: ${item['fnameU']}  ${item['lnameU']}",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    leading: CircleAvatar(
                      backgroundColor: MyColors.primaryColor,
                      child: Text(
                        '${item['blood_group']}',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            fontSize: 20),
                      ),
                      minRadius: 20,
                      maxRadius: 30,
                    ),
                    trailing: Column(
                      children: [
                        IconButton(
                            onPressed: () {
                              //  _delete(item['_id']);
                            },
                            icon: Icon(Icons.menu)),
                      ],
                    ),
                    subtitle: Text(
                      '\nBankName : ${item['bank']} \nContact No: ${item['Mobile']}\nCity : ${item['cityU']} ',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                  Divider(
                    color: Colors.black,
                    thickness: 1,
                  )
                ],
              ),
            );
          }),
    );
  }

  void _query() async {
    final allRows = await myDBhelper.queryAllbloodlist();
    print('query all rows:');
    allRows.forEach(print);
    allBlooddone = allRows;
    setState(() {});
  }
}
